DHANCRI Studio — identidad provisional v0.1
Logotipo tipográfico en minúsculas, sin anagrama.
Azul: #0872C4 | Gris: #727B88 | Fondo oscuro: #172634
Fuente de referencia: Comfortaa Bold / Regular (convertida a trazados en SVG).
Los SVG contienen trazados vectoriales y no dependen de fuentes instaladas.
PNG: 1800 x 540 px. La versión clara tiene fondo transparente; la oscura lleva fondo sólido.
Esta es una interpretación vectorial de la dirección A aprobada, no una reproducción exacta de la imagen conceptual.
